import React, { Component } from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { usernameAction } from './actions/actions.js';
import { BrowserRouter as Router } from 'react-router-dom';
import Route from 'react-router-dom/Route'
import { Redirect } from 'react-router'
import logo from './logo.svg';
import * as api from './api';
import App2 from './App2';
import './Steps.css';
import Step from './Step'
import UserPanel from './UserPanel';

class Popup extends Component {
  render() {
    return (
      <div className="popup2">
        <div className="popup_inner2">
          <h1>{this.props.text}</h1>
            <div className="Create-new-step">
              <input 
              className="Step-var" 
              placeholder={'Step...'}
              onChange={this.props.updateStep}
              />
              <button onClick={this.props.createStep}>
                Create step
              </button>
            </div>
          <button onClick={this.props.closePopup}> Done </button>
        </div>
      </div>
    );
  }
}

class Steps extends Component {

  constructor(props) {
        super(props);
        this.state = {
            toApp2: false,
            goal: '',
            showProposed: false,
            step: '',
            steps: [],
            index: 0,
            popUp: false
        };
        // Arrow functions declared in constructor are the only ones that can be accessed by rendered components
        // and provide access to the current state

        this.toApp2 = () => {
            this.presentApp2();
        };
        
        console.log(`Steps user and goal: ${this.props.username}, ${this.props.location.state.goal}`);

        // Until arrow functions, every new function defined its own this value. 
        // This proved to be annoying with an object-oriented style of programming.
        // Arrow functions capture the this value of the enclosing context.
        // Binding a new function to this instance means it can be used by it.
        
        this.showProposed = this.showProposed.bind(this);
    }

  componentDidMount() {
        this.setState({ goal: this.props.location.state.goal });
  }

  // This is one of the methods to be passed as a prop to the Popup component to click out of it from there
  presentPopUp() {
    this.setState({ popUp: !this.state.popUp });
  }

  updateStep = (e) => {
        this.setState({
            step: e.target.value
        });
  }

  prepareInsert(index) {
    console.log(`index: ${index}`);
    this.setState({
        index: index
    });
    this.presentPopUp();
  }

  async createStep() {
    console.log(`createStep: ${this.state.step}`);
    let stepsIndex;
    let stepsCount = this.state.steps.length;
    if (this.state.index === -1) {
      // At first insert
      if (stepsCount === 0) {
        // Base index is as large as possible for steps to-be-inserted before while having addition space left for steps to-be-inserted after
        // JavaScript numbers allow for 15 digits max, so 2^46 for clean divisions by half before going into decimal between steps for inserts
        // 2^46 also doesn't overflow 15 digits when doubled, which is important because averages between stepsIndexes need to be calculated
        // Also doesn't overflow 20 integer decimals given in table, and has enough addition space left for ~3000 increments of 2^33
        stepsIndex = 70368744177664;
      } else {
        // Can be able to be a decimal value
        stepsIndex = this.state.steps[0].stepsIndex/2;
      }
    } else if (this.state.index === stepsCount - 1) {
      // At last insert
      stepsIndex = this.state.steps[stepsCount - 1].stepsIndex + 8589934592;
    } else {
      // At insert in the middle
      stepsIndex = (this.state.steps[this.state.index].stepsIndex + this.state.steps[this.state.index + 1].stepsIndex)/2;
    }
    console.log(`createStep stepsIndex: ${stepsIndex}`);
    const token = localStorage.getItem('token');
    const prospectiveStep = {
      goal: this.state.goal,
      step: this.state.step,
      username: this.props.username,
      stepsIndex: stepsIndex
    }; 
    console.log(`prospectiveStep: ${prospectiveStep.goal}, ${prospectiveStep.step}, ${prospectiveStep.username}, ${prospectiveStep.stepsIndex}`);
    const createResult = await api.createStep(prospectiveStep, token);
    if (createResult.success === true) {
      console.log(`Success: ${createResult.message}, stepsIndex: ${stepsIndex}`);
      this.setSteps(prospectiveStep.goal);
      this.presentPopUp();
    } else {
      console.log(`Failed: ${createResult.message}`);
      this.presentPopUp();
    }
  }

  async endorseStep(step) {
        const token = localStorage.getItem('token');
        const specificStep = {
            goal: this.state.goal,
            step: step,
            endorsed: true
        };
        console.log(`specificStep: ${specificStep.goal}, ${specificStep.step}, ${specificStep.endorsed}`);
        const endorseResult = await api.patchStep(specificStep, token);
        if (endorseResult.success === true) {
          console.log(`Success: ${endorseResult.message}`);
        } else {
          console.log(`Failed: ${endorseResult.message}`);
        }
  }

  async opposeStep(step) {
        const token = localStorage.getItem('token');
        const specificStep = {
            goal: this.state.goal,
            step: step,
            endorsed: false
        };
        const opposeResult = await api.patchStep(specificStep, token);
        if (opposeResult.success === true) {
          console.log(`Success: ${opposeResult.message}`);
        } else {
          console.log(`Failed: ${opposeResult.message}`);
        }
  }

  presentApp2() {
        this.setState({ toApp2: true });
  }

  async setSteps(goal) {
        const forGoal = {
             goal: goal
        };
        const token = localStorage.getItem('token');
        const steps = await api.getSteps(forGoal, token);
        // Goals is a RowDataPacket of rows that can be subscripted
        // and each one's values are accessed by property ID's
        console.log(`setSteps message: ${steps.message}`);
        if (steps.success === true) {
          console.log(`setSteps: ${steps.data[0]}, ${steps.data[1][0].username}`);
          this.setState({
              steps: steps.data[0]
          });
          console.log(`steps: ${this.state.steps}`);
        }
  }

  async showProposed() {
        this.setState({
              showProposed: !this.state.showProposed
        });
  }

  // async showInserts() {
  //       console.log('showProposed!');
  //       this.setState({
  //             showProposed: !this.state.showProposed
  //       });
  // }

  render() {

    if (this.state.toApp2 === true) {
      return <Redirect to="/App2" />
    }

      const { steps } = this.state;
      let cards;
      if (steps.length !== 0) {
          
          if (this.state.showProposed === false) {
            const cardsFiltered = steps.filter(function(step) {
              return step.approved === 1;
            });

            // 'step' is the Step data and 'key' is the index in cardsFiltered. 'key' is for React internal use, so also have an 'index' prop
            cards = cardsFiltered.map((step, key) => (
              <Step 
                key={key}
                index={key}
                step={step.step}
                userID={step.username}
                timeStamp={this.formatDate(step.timeStamp)}
                status={step.approved}
                endorse={this.endorseStep.bind(this)}
                oppose={this.opposeStep.bind(this)}
                prepare={this.prepareInsert.bind(this)}
              />
            ));

          } else {

            cards = steps.map((step, key) => (
              <Step 
                key={key}
                index={key}
                step={step.step}
                userID={step.username}
                timeStamp={this.formatDate(step.timeStamp)}
                status={step.approved}
                endorse={this.endorseStep.bind(this)}
                oppose={this.opposeStep.bind(this)}
                prepare={this.prepareInsert.bind(this)}
              />
            ));
          }
      } else {
          cards = (<h1 style={{ fontSize: '3vw' }}>
              There are no steps right now.
          </h1>);
      }

    return (
      <div className="Steps">
        <header className="Steps-header">
          <button onClick={() => this.setSteps(this.state.goal)}>
            Get steps
          </button>
          <button onClick={this.toApp2}>
            Go to App2
          </button>
          <button onClick={this.showProposed}>
            Show 
          </button>
        </header>
        <img src={require('./assets/insertIcon.png')} alt='Ins' onClick={() => this.prepareInsert(-1)} style={{ position : 'absolute', marginLeft : '30vw', marginTop : '-20px' }} width='128' height='128' />
        <div className="Steps-list">
          {cards}
        </div>
        <footer>
          <UserPanel currentUser={this.props.username} />
        </footer>
        {this.state.popUp ? 
          <Popup
            text='Create a Step'
            closePopup={this.presentPopUp.bind(this)}
            updateStep={this.updateStep.bind(this)}
            createStep={this.createStep.bind(this)}
          />
          : null
        }
      </div>
    );
  }

  formatDate(date) {
    var newDate = new Date(date);
    console.log(`Date: ${newDate}`);
    var hours = newDate.getHours();
    var minutes = newDate.getMinutes();
    var ampm = hours >= 12 ? 'pm' : 'am';
    hours = hours % 12;
    hours = hours ? hours : 12; 
    minutes = minutes < 10 ? '0'+minutes : minutes;
    var strTime = hours + ':' + minutes + ' ' + ampm;
    return newDate.getMonth()+1 + "/" + newDate.getDate() + "/" + newDate.getFullYear() + "  " + strTime;
  }

}

// Passes this data from store to component in form of props.
// This returns the props the component uses
const mapStateToProps = (state) => {
  console.log(`State: ${state.state.username}`);
  return {
    username: state.state.username
  }
}

// Attach to component's props and will dispatch the action in question 
// to the reducer to be turned into state in the store.
// This creates the action to call to change the store
const mapDispatchToProps = (dispatch) => {
  return bindActionCreators({ usernameAction }, dispatch);
}

// This links them all together
export default connect(mapStateToProps, mapDispatchToProps)(Steps);
//export default Steps;