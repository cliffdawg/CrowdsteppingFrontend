let defaultState = {
	username: localStorage.getItem('username') || 'No User'
}

// This returns a changed store based on received action
const reducers = (state = defaultState, action) => {
	switch(action.type) {
		case 'UPDATE-USERNAME':
		 localStorage.setItem('username', action.payload);
		 return {
		 	...state,
		 	username: action.payload
		 }
		 default: return state;
	}
}

export default reducers;