import React from 'react';
import './Step.css'

const Step = ({index, step, userID, timeStamp, status, endorse, oppose, prepare}) => (
	<div className="step" style={{ marginLeft : status ? 0 : 140, backgroundColor : status ? 'blue' : 'green' }} >
		<div className="step-info">
			<div className="step-title">
				<label>
	            	{step}
	          	</label>
			</div>
			<div className="step-identifiers">
				<div>
					{userID}
				</div>
				<div>
					{timeStamp}
				</div>
			</div>
		</div>
		<div className="step-buttons">
			<button onClick={() => endorse(step)}>
           		Endorse
         	</button>
          	<button onClick={() => oppose(step)}>
            	Oppose 
          	</button>
		</div>

		<img src={require('./assets/insertIcon.png')} alt='Ins' onClick={() => prepare(index)} style={{ position : 'absolute', marginLeft : status ? '35vw' : '29.5vw', marginTop : '80px' }} width='128' height='128' />

	</div>
);

export default Step;