import React, { Component } from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { usernameAction } from './actions/actions.js';
import { BrowserRouter as Router } from 'react-router-dom';
import Route from 'react-router-dom/Route'
import { Redirect } from 'react-router'
import logo from './logo.svg';
import * as api from './api';
import App2 from './App2';
import './App.css';

// Redux store and web tokens are kept in browser memory

class App extends Component {

  constructor() {
        super();
        this.state = {
            number: 0,
            toApp2: false,
            username: '',
            password: '',
            username2: '',
            email: '',
            password2: ''
        };
        // Arrow functions declared in constructor are the only ones that can be accessed by rendered components
        // and provide access to the current state

        // Cannot name declared functions the same as actual state's functions
        this.refreshNumber = () => { 
            this.getNumber();
        };
        this.toApp2 = () => {
            this.presentApp2();
        };
        this.login = () => {
            this.logIn();
        };
        this.signup = () => {
            this.signUp();
        };
    }

  async getNumber() {
        const num = await api.getNumber();
        this.setState({ 
            number: num 
        });
  }

  presentApp2() {
        this.setState({ 
            toApp2: true 
        });
  }

  updateUsername = (e) => {
        this.setState({
            username: e.target.value
        });
  }

  updatePassword = (e) => {
        this.setState({
            password: e.target.value
        });
  }

  updateUsername2 = (e) => {
        this.setState({
            username2: e.target.value
        });
  }

  updateEmail = (e) => {
        this.setState({
            email: e.target.value
        });
  }

  updatePassword2 = (e) => {
        this.setState({
            password2: e.target.value
        });
  }

  async logIn() {
    const { username, password } = this.state;
    console.log(`${username}, ${password}`);
    const newLogin = {
            username: username,
            password: password
        };
    const loginResult = await api.signIn(newLogin);
    
    if (loginResult.success) {
      localStorage.setItem('token', loginResult.token);
      this.props.usernameAction(username);
      this.toApp2();
    } else {
      console.log(`loginResult: ${loginResult.message}`);
    }
  }

  async signUp() {
    const { username2, email, password2 } = this.state;
    console.log(`${username2}, ${email}, ${password2}`);
    const newSignup = {
            username: username2,
            email: email,
            password: password2
        };
    const signupResult = await api.signUp(newSignup);
    
    if (signupResult.success) {
      console.log(`token2: ${signupResult.token}`);
      localStorage.setItem('token', signupResult.token);
      this.props.usernameAction(username2);
      this.toApp2();
    } else {
      console.log(`signupResult: ${signupResult.message}`);
    }
  }

  render() {

    if (this.state.toApp2 === true && token) {
      return <Redirect to="/App2" />
    }

    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt='logo' />
          <p>
            Edit <code>src/App.js</code> and save to reload.
          </p>
          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
          >
            Learn React
          </a>
          <button className="number-button" onClick={this.refreshNumber}>
            Get a number
          </button>
          <label>
            {this.state.number}
          </label>
          <button onClick={this.toApp2}>
            Go to App2
          </button>
          <input 
            className="log-in username" 
            placeholder={"Username..."}
            onChange={this.updateUsername}
          />
          <input 
            className="log-in password" 
            placeholder={"Password..."}
            onChange={this.updatePassword}
          />
          <button onClick={this.login}>
            Login
          </button>
          <input 
            className="sign-up username" 
            placeholder={"Username..."}
            onChange={this.updateUsername2}
          />
          <input 
            className="sign-up email" 
            placeholder={"Email..."}
            onChange={this.updateEmail}
          />
          <input 
            className="sign-up password" 
            placeholder={"Password..."}
            onChange={this.updatePassword2}
          />
          <button onClick={this.signup}>
            Sign Up
          </button>
        </header>
      </div>
    );
  }
}

// Passes this data from store to component in form of props.
// This returns the props the component uses
const mapStateToProps = (state) => {
  console.log(`State: ${state.state.username}`);
  return {
    username: state.state.username
  }
}

// Attach to component's props and will dispatch the action in question 
// to the reducer to be turned into state in the store.
// This creates the action to call to change the store
const mapDispatchToProps = (dispatch) => {
  return bindActionCreators({ usernameAction }, dispatch);
}

// This links them all together
export default connect(mapStateToProps, mapDispatchToProps)(App);

//export default App;
