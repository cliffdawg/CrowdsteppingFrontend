// When using a proxy, cannot use root endpoint '/' for route, will return HTML
//const APIURL = '/api';
const APIURL = '';

const throwError = async (resp) => {
    const unknownErr = { errorMessage: 'Unknown error' };
    try {
        const body = await resp.json();
        if (body.message !== undefined) {
            let err = { errorMessage: body.message };
            throw err;
        } else {
            throw unknownErr;
        }
    } catch (e) {
        throw unknownErr;
    }
};

const signIn = async (credentials) => {
    console.log(`credentials: ${credentials.username}`);
    const resp = await fetch(APIURL + '/signin', {
        method: 'POST',
        headers: new Headers({
            'Content-Type': 'application/json'
        }),
        body: JSON.stringify(credentials)
    });
    if (!resp.ok) {
        throwError(resp);
    } else {
        return resp.json();
    }
};

const signUp = async (post, token) => {
    // username
    // email
    // password
    console.log(`post: ${post}`);
    const resp = await fetch(APIURL + '/signUp', {
        method: 'POST',
        headers: new Headers({
            'Content-Type': 'application/json'
        }),
        body: JSON.stringify(post)
    });
    if (!resp.ok) {
        throwError(resp);
    } else {
        return resp.json();
    }
};

const getGoals = async (token) => {
    //APIURL,
    console.log(`getGoals: ${token}`)
    const resp = await fetch(APIURL + '/goals', {
        method: 'GET',
        headers: new Headers({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        })
    });
    if (!resp.ok) {
        throwError(resp);
    } else {
        return resp.json();
    }
}; 

const createGoal = async (post, token) => {
    console.log(`post: ${post}`);
    //APIURL,
    const resp = await fetch(APIURL + '/goal', {
        method: 'POST',
        headers: new Headers({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        }),
        body: JSON.stringify(post)
    });
    if (!resp.ok) {
        throwError(resp);
    } else {
        return resp.json();
    }
};

const getSteps = async (goal, token) => {
    //APIURL,
    console.log(`getSteps: ${token}`)
    const resp = await fetch(APIURL + '/steps', {
        method: 'POST',
        headers: new Headers({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        }),
        body: JSON.stringify(goal)
    });
    if (!resp.ok) {
        throwError(resp);
    } else {
        return resp.json();
    }
}; 

const createStep = async (prospectiveStep, token) => {
    //APIURL,
    console.log(`create step: ${prospectiveStep.goal}, ${prospectiveStep.step}`);
    const resp = await fetch(APIURL + '/step', {
        method: 'POST',
        headers: new Headers({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        }),
        body: JSON.stringify(prospectiveStep)
    });
    if (!resp.ok) {
        throwError(resp);
    } else {
        return resp.json();
    }
}; 

const patchStep = async (specificStep, token) => {
    //APIURL,
    console.log(`patch step: ${specificStep.goal}, ${specificStep.step}, ${specificStep.endorsed}`);
    const resp = await fetch(APIURL + '/step', {
        method: 'PATCH',
        headers: new Headers({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        }),
        body: JSON.stringify(specificStep)
    });
    if (!resp.ok) {
        throwError(resp);
    } else {
        return resp.json();
    }
}; 

const getNumber = async () => {
    //APIURL,
    const resp = await fetch(APIURL + '/');
    if (!resp.ok) {
        console.log('api getNumber fail');
        throwError(resp);
    } else {
        console.log('api getNumber okay', resp);
        return resp.json();
    }
};

export {
    signIn,
    signUp,
    getGoals,
    createGoal,
    getSteps,
    createStep,
    patchStep,
    getNumber
};