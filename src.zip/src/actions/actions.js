// Action used to modify store data
export const usernameAction = (username) => (
	{
		type: 'UPDATE-USERNAME',
		payload: username
	}
)